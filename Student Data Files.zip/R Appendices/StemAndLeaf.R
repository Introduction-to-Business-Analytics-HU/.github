aptitude_df <- read.csv("AptitudeTest.csv")
aptitude_scores <- aptitude_df$Correct
stem(aptitude_scores)