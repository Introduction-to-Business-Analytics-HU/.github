softdrink_df <- read.csv("SoftDrink.csv")
table(softdrink_df)
barplot(table(softdrink_df))