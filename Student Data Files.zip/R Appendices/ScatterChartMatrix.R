nycitydata_df <- read.csv("NYCityData.csv")
pairs(nycitydata_df[,2:5])